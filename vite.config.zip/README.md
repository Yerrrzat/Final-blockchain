# CourseFund (Frontend)

React + Vite frontend for the CourseFund crowdfunding DApp.

## Requirements

- Node.js 18+
- MetaMask
- Sepolia testnet ETH

## Setup

1) Install dependencies

- `npm install`

2) Configure contract addresses

- Copy `.env.example` to `.env`
- Fill in your deployed Sepolia addresses:
  - `VITE_COURSEFUND_ADDRESS`
  - `VITE_REWARDTOKEN_ADDRESS`

Optional (recommended): configure a Sepolia RPC URL so anyone can browse campaigns without connecting MetaMask:

- `VITE_SEPOLIA_RPC_URL`

3) Paste ABIs

Replace these placeholder ABI files with your real ABIs:

- `src/abi/CourseFund.json`
- `src/abi/RewardToken.json`

Supported formats:

- Plain ABI array: `[{"type":"function", ...}]`
- Hardhat artifact JSON containing `abi`: `{ "abi": [...] }`

## Run

- `npm run dev`

Then open http://localhost:5173

## Quick address check (recommended)

If you suspect the app is using the wrong addresses (or campaigns don’t appear), run:

- `npm run check:sepolia`

This validates:

- `VITE_COURSEFUND_ADDRESS` has deployed bytecode on Sepolia
- `VITE_REWARDTOKEN_ADDRESS` has deployed bytecode on Sepolia
- `CourseFund.rewardToken()` matches your `VITE_REWARDTOKEN_ADDRESS`
- (if available) `CourseToken.owner()` is the CourseFund (required if CourseFund mints rewards)

This command requires `VITE_SEPOLIA_RPC_URL` (or `SEPOLIA_RPC_URL`) so it can query Sepolia.

## Deploy (optional)

If you don't have working Sepolia contract addresses yet, you can deploy fresh contracts from this repo.

1) Generate deploy artifacts (ABI + bytecode)

- `npm run compile:artifacts`

2) Set deploy environment variables (DO NOT put your private key in git)

- `SEPOLIA_RPC_URL=...` (or reuse the same value via `VITE_SEPOLIA_RPC_URL`)
- `DEPLOYER_PRIVATE_KEY=...` (32-byte hex, with or without `0x`)

3) Deploy

- `npm run deploy:sepolia`

Optional: write the resulting addresses into `.env.local` automatically:

- `npm run deploy:sepolia -- --write-env`

The script prints the `VITE_REWARDTOKEN_ADDRESS` and `VITE_COURSEFUND_ADDRESS` values for the frontend.

## Troubleshooting

- If you are not on Sepolia, the UI will warn you.
- If the campaigns list is empty until you connect a wallet, add `VITE_SEPOLIA_RPC_URL` (read-only provider for public browsing).
- If your CourseFund contract uses different function names/parameters for campaign creation or donation, update the wrapper logic in `src/web3/contracts.js`.
- Sepolia Etherscan links are shown for transactions.
