import fs from 'fs';
import path from 'path';
import { ethers } from 'ethers';

function readTextIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return null;
  }
}

function parseDotEnv(text) {
  const result = {};
  const lines = text.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    result[key] = value;
  }
  return result;
}

function loadEnv() {
  const merged = { ...process.env };
  const envLocal = readTextIfExists(path.resolve('.env.local'));
  const env = readTextIfExists(path.resolve('.env'));
  const parsedLocal = envLocal ? parseDotEnv(envLocal) : {};
  const parsedEnv = env ? parseDotEnv(env) : {};

  for (const [k, v] of Object.entries({ ...parsedEnv, ...parsedLocal })) {
    if (merged[k] == null || merged[k] === '') merged[k] = v;
  }
  return merged;
}

function requireAddress(name, value) {
  if (!value) throw new Error(`Missing ${name}.`);
  if (!ethers.isAddress(value)) throw new Error(`${name} is not a valid address: ${value}`);
  return value;
}

function getRpcProvider(env) {
  const rpcUrl = (env.SEPOLIA_RPC_URL || env.VITE_SEPOLIA_RPC_URL || '').trim();
  if (!rpcUrl) {
    throw new Error(
      'Missing VITE_SEPOLIA_RPC_URL (or SEPOLIA_RPC_URL).\n' +
        'Provide a Sepolia RPC endpoint so this script can query chain state.\n' +
        'Example: set VITE_SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/<key>'
    );
  }
  return new ethers.JsonRpcProvider(rpcUrl);
}

async function safeGetCode(provider, address) {
  try {
    return await provider.getCode(address);
  } catch (e) {
    throw new Error(`Failed to fetch code for ${address}. If you hit rate-limits, set VITE_SEPOLIA_RPC_URL. Details: ${e?.message ?? e}`);
  }
}

async function main() {
  const env = loadEnv();

  const courseFundAddress = requireAddress('VITE_COURSEFUND_ADDRESS', env.VITE_COURSEFUND_ADDRESS);
  const rewardTokenAddress = requireAddress('VITE_REWARDTOKEN_ADDRESS', env.VITE_REWARDTOKEN_ADDRESS);

  const provider = getRpcProvider(env);
  const network = await provider.getNetwork();

  console.log('Network   :', network.name, `(chainId ${network.chainId})`);
  console.log('CourseFund:', courseFundAddress);
  console.log('RewardTok :', rewardTokenAddress);

  if (network.chainId !== 11155111n) {
    console.log('WARNING   : provider is not Sepolia; results may be wrong.');
  }

  console.log('\nChecking deployed bytecode...');
  const [cfCode, rtCode] = await Promise.all([
    safeGetCode(provider, courseFundAddress),
    safeGetCode(provider, rewardTokenAddress),
  ]);

  console.log('  CourseFund code:', cfCode && cfCode !== '0x' ? 'OK' : 'MISSING');
  console.log('  RewardToken code:', rtCode && rtCode !== '0x' ? 'OK' : 'MISSING');

  if (!cfCode || cfCode === '0x') {
    throw new Error('CourseFund address has no code. Set VITE_COURSEFUND_ADDRESS to the contract you deployed on Sepolia.');
  }
  if (!rtCode || rtCode === '0x') {
    throw new Error('RewardToken address has no code. Set VITE_REWARDTOKEN_ADDRESS to the token you deployed on Sepolia.');
  }

  console.log('\nChecking CourseFund.rewardToken()...');
  const courseFundAbi = [
    'function rewardToken() view returns (address)',
    'function campaignCount() view returns (uint256)',
  ];
  const courseFund = new ethers.Contract(courseFundAddress, courseFundAbi, provider);

  let onChainToken;
  try {
    onChainToken = await courseFund.rewardToken();
    console.log('  on-chain rewardToken:', onChainToken);
  } catch (e) {
    throw new Error(`CourseFund.rewardToken() call failed. This usually means VITE_COURSEFUND_ADDRESS is not your CourseFund contract. Details: ${e?.message ?? e}`);
  }

  if (onChainToken.toLowerCase() !== rewardTokenAddress.toLowerCase()) {
    console.log('\nMISMATCH:');
    console.log('  Your .env VITE_REWARDTOKEN_ADDRESS does NOT match CourseFund.rewardToken().');
    console.log('  Fix: set VITE_REWARDTOKEN_ADDRESS to:', onChainToken);
  } else {
    console.log('  OK: .env token matches CourseFund.rewardToken()');
  }

  console.log('\nChecking CourseFund.campaignCount()...');
  try {
    const count = await courseFund.campaignCount();
    console.log('  campaignCount:', count.toString());
  } catch (e) {
    console.log('  WARNING: campaignCount() failed:', e?.message ?? e);
  }

  console.log('\nChecking token.owner() (optional)...');
  const tokenAbi = ['function owner() view returns (address)'];
  const token = new ethers.Contract(rewardTokenAddress, tokenAbi, provider);
  try {
    const owner = await token.owner();
    console.log('  token.owner():', owner);
    if (owner.toLowerCase() !== courseFundAddress.toLowerCase()) {
      console.log('  NOTE: token owner is not CourseFund. If donate/contribute mints tokens, you must call transferOwnership(CourseFundAddress).');
    } else {
      console.log('  OK: token owner is CourseFund');
    }
  } catch (e) {
    console.log('  Skipped: owner() not available on this token ABI:', e?.message ?? e);
  }

  console.log('\nDone.');
}

main().catch((err) => {
  console.error('\nERROR:', err?.message ?? err);
  process.exit(1);
});
