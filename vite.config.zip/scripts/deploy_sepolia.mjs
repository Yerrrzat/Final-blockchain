import fs from 'fs';
import path from 'path';
import { ethers } from 'ethers';

function readTextIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return null;
  }
}

function parseDotEnv(text) {
  const result = {};
  const lines = text.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    // do not expand vars; keep simple
    result[key] = value;
  }
  return result;
}

function loadEnv() {
  // Priority: real environment vars win, but we also load from .env.local and .env
  const merged = { ...process.env };
  const envLocal = readTextIfExists(path.resolve('.env.local'));
  const env = readTextIfExists(path.resolve('.env'));
  const parsedLocal = envLocal ? parseDotEnv(envLocal) : {};
  const parsedEnv = env ? parseDotEnv(env) : {};

  // Only fill missing keys from files (do not override terminal env)
  for (const [k, v] of Object.entries({ ...parsedEnv, ...parsedLocal })) {
    if (merged[k] == null || merged[k] === '') merged[k] = v;
  }
  return merged;
}

function getArgFlag(name) {
  return process.argv.includes(name);
}

function getArgValue(name) {
  const idx = process.argv.indexOf(name);
  if (idx === -1) return undefined;
  const val = process.argv[idx + 1];
  if (!val || val.startsWith('--')) return undefined;
  return val;
}

function updateEnvFile(filePath, updates) {
  const existing = readTextIfExists(filePath) ?? '';
  const lines = existing.split(/\r?\n/);

  const keys = Object.keys(updates);
  const seen = new Set();

  const outLines = lines.map((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) return line;
    const eq = line.indexOf('=');
    if (eq === -1) return line;
    const key = line.slice(0, eq).trim();
    if (!keys.includes(key)) return line;
    seen.add(key);
    return `${key}=${updates[key]}`;
  });

  for (const key of keys) {
    if (!seen.has(key)) outLines.push(`${key}=${updates[key]}`);
  }

  // Normalize trailing newline
  const out = outLines.join('\n').replace(/\n+$/g, '\n');
  fs.writeFileSync(filePath, out, 'utf8');
}

function requireHexPrivateKey(pk) {
  if (!pk) throw new Error('Missing DEPLOYER_PRIVATE_KEY (hex string, 0x... or without 0x).');
  const normalized = pk.startsWith('0x') ? pk : `0x${pk}`;
  if (!/^0x[0-9a-fA-F]{64}$/.test(normalized)) {
    throw new Error('DEPLOYER_PRIVATE_KEY must be 32-byte hex (64 hex chars).');
  }
  return normalized;
}

function requireUrl(url) {
  if (!url) throw new Error('Missing SEPOLIA_RPC_URL (for deployment). You can also set VITE_SEPOLIA_RPC_URL and the deploy script will reuse it.');
  return url;
}

function loadArtifacts() {
  const artifactsPath = path.resolve('src/abi/DeployArtifacts.json');
  if (!fs.existsSync(artifactsPath)) {
    throw new Error('Missing src/abi/DeployArtifacts.json. Run: npm run compile:artifacts');
  }
  const json = JSON.parse(fs.readFileSync(artifactsPath, 'utf8'));
  if (!json?.CourseToken?.abi || !json?.CourseToken?.bytecode) throw new Error('DeployArtifacts.json missing CourseToken');
  if (!json?.CourseFund?.abi || !json?.CourseFund?.bytecode) throw new Error('DeployArtifacts.json missing CourseFund');
  return json;
}

async function main() {
  const env = loadEnv();

  const rpcUrl = requireUrl(env.SEPOLIA_RPC_URL || env.VITE_SEPOLIA_RPC_URL);
  const privateKey = requireHexPrivateKey(env.DEPLOYER_PRIVATE_KEY);

  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const network = await provider.getNetwork();
  if (network.chainId !== 11155111n) {
    throw new Error(`RPC is not Sepolia (expected chainId 11155111, got ${network.chainId}).`);
  }

  const wallet = new ethers.Wallet(privateKey, provider);
  const balance = await provider.getBalance(wallet.address);
  console.log('Deployer:', wallet.address);
  console.log('Balance :', ethers.formatEther(balance), 'ETH');

  const artifacts = loadArtifacts();

  console.log('\nDeploying CourseToken...');
  const tokenFactory = new ethers.ContractFactory(artifacts.CourseToken.abi, artifacts.CourseToken.bytecode, wallet);
  const token = await tokenFactory.deploy();
  const tokenDeployTx = token.deploymentTransaction();
  console.log('  tx:', tokenDeployTx?.hash ?? '(unknown)');
  await token.waitForDeployment();
  const tokenAddress = await token.getAddress();
  console.log('  addr:', tokenAddress);

  console.log('\nDeploying CourseFund(token)...');
  const fundFactory = new ethers.ContractFactory(artifacts.CourseFund.abi, artifacts.CourseFund.bytecode, wallet);
  const fund = await fundFactory.deploy(tokenAddress);
  const fundDeployTx = fund.deploymentTransaction();
  console.log('  tx:', fundDeployTx?.hash ?? '(unknown)');
  await fund.waitForDeployment();
  const fundAddress = await fund.getAddress();
  console.log('  addr:', fundAddress);

  console.log('\nTransferring CourseToken ownership to CourseFund...');
  const tokenContract = new ethers.Contract(tokenAddress, artifacts.CourseToken.abi, wallet);
  const tx = await tokenContract.transferOwnership(fundAddress);
  console.log('  tx:', tx.hash);
  await tx.wait();
  console.log('  ok');

  console.log('\nFrontend env values:');
  console.log(`  VITE_REWARDTOKEN_ADDRESS=${tokenAddress}`);
  console.log(`  VITE_COURSEFUND_ADDRESS=${fundAddress}`);

  const writeEnv = getArgFlag('--write-env');
  const writeTo = getArgValue('--env-file') ?? '.env.local';

  if (writeEnv) {
    updateEnvFile(path.resolve(writeTo), {
      VITE_REWARDTOKEN_ADDRESS: tokenAddress,
      VITE_COURSEFUND_ADDRESS: fundAddress,
    });
    console.log(`\nWrote addresses to ${writeTo}`);
  } else {
    console.log('\nTip: run with --write-env to write these into .env.local');
    console.log('     example: npm run deploy:sepolia -- --write-env');
  }

  console.log('\nNext: open the app and (optional) paste these in Contract Settings.');
}

main().catch((err) => {
  console.error('\nERROR:', err?.message ?? err);
  process.exit(1);
});
