import { useEffect, useMemo, useState } from 'react';

import './App.css';

import Wallet from './components/Wallet';
import BalancePanel from './components/BalancePanel';
import CreateCampaign from './components/CreateCampaign';
import CampaignList from './components/CampaignList';
import ContractSettings from './components/ContractSettings';
import ContributionForm from './components/ContributionForm';

import { getCourseFundContract, getRewardTokenContract, hasConfiguredAddresses, validateCourseFundDeployment } from './web3/contracts';
import { getReadOnlySepoliaProvider } from './web3/provider';

const demoCampaigns = [
  {
    id: 0n,
    title: 'Solidity Study Jam: Week 1-4',
    summary: 'A structured sprint from fundamentals to deploying on Sepolia. Daily tasks + weekly live review.',
    level: 'Beginner -> Intermediate',
    perks: ['ERC20 rewards for donations', 'Discord access', 'Weekly Q&A'],
    syllabus: ['Solidity basics', 'Storage & memory', 'Events + errors', 'Deploy & verify on Sepolia'],
    goal: 2n * 10n ** 18n,
    raised: 650000000000000000n,
    deadline: BigInt(Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60),
    creator: '0x1111111111111111111111111111111111111111',
  },
  {
    id: 1n,
    title: 'Frontend for DApps (React + ethers v6)',
    summary: 'Build a production-feeling DApp UI: wallet UX, tx states, data fetching, and clean components.',
    level: 'Intermediate',
    perks: ['Project template', 'Best-practices checklist', 'Code review session'],
    syllabus: ['MetaMask connect', 'ethers v6 contracts', 'Loading/Errors', 'Etherscan links', 'UX polish'],
    goal: 15n * 10n ** 17n,
    raised: 1200000000000000000n,
    deadline: BigInt(Math.floor(Date.now() / 1000) + 14 * 24 * 60 * 60),
    creator: '0x2222222222222222222222222222222222222222',
  },
  {
    id: 2n,
    title: 'Auditing Basics Mini-Course',
    summary: 'Learn how to read contracts like an auditor: threat modeling, common bugs, and test-driven checks.',
    level: 'Intermediate -> Advanced',
    perks: ['Vuln checklist', 'Practice repo', 'Bonus reading list'],
    syllabus: ['Reentrancy', 'Access control', 'Oracle issues', 'Integer pitfalls', 'Testing patterns'],
    goal: 5n * 10n ** 18n,
    raised: 4500000000000000000n,
    deadline: BigInt(Math.floor(Date.now() / 1000) + 3 * 24 * 60 * 60),
    creator: '0x3333333333333333333333333333333333333333',
  },
];

function EnvNotice() {
  return (
    <div className="card">
      <div className="warn">
        Missing contract addresses. Create a <span className="mono">.env</span> file from <span className="mono">.env.example</span> and set
        <span className="mono"> VITE_COURSEFUND_ADDRESS</span> and <span className="mono">VITE_REWARDTOKEN_ADDRESS</span>.
      </div>
    </div>
  );
}

export default function App() {
  const [connection, setConnection] = useState(null);
  const [courseFund, setCourseFund] = useState(null);
  const [rewardToken, setRewardToken] = useState(null);
  const [publicCourseFund, setPublicCourseFund] = useState(null);
  const [envError, setEnvError] = useState('');
  const [refreshNonce, setRefreshNonce] = useState(0);
  const [createdCampaignHint, setCreatedCampaignHint] = useState(null);

  const isConnected = Boolean(connection?.address);

  const hasAddresses = useMemo(() => {
    return hasConfiguredAddresses();
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function initPublicReadOnly() {
      if (!hasAddresses) {
        setPublicCourseFund(null);
        return;
      }

      if (isConnected) {
        setPublicCourseFund(null);
        return;
      }

      try {
        const provider = await getReadOnlySepoliaProvider();
        await validateCourseFundDeployment(provider);
        const contract = getCourseFundContract(provider);
        if (!cancelled) setPublicCourseFund(contract);
      } catch (e) {
        if (!cancelled) {
          setPublicCourseFund(null);
          setEnvError(e?.message ?? String(e));
        }
      }
    }

    initPublicReadOnly();
    return () => {
      cancelled = true;
    };
  }, [hasAddresses, isConnected]);

  const demoMode = useMemo(() => {
    const raw = import.meta.env.VITE_DEMO_MODE;
    if (raw == null) return true;
    return String(raw).toLowerCase() === 'true';
  }, []);

  const onConnected = (conn) => {
    setConnection(conn);
    setEnvError('');

    try {
      setCourseFund(getCourseFundContract(conn.signer));
      setRewardToken(getRewardTokenContract(conn.signer));
    } catch (e) {
      setCourseFund(null);
      setRewardToken(null);
      setEnvError(e?.message ?? String(e));
    }

    // Validate addresses against deployed bytecode (prevents no-op txs).
    (async () => {
      try {
        await validateCourseFundDeployment(conn.provider);
      } catch (e) {
        setCourseFund(null);
        setRewardToken(null);
        setEnvError(e?.message ?? String(e));
      }
    })();
  };

  const onDisconnected = () => {
    setConnection(null);
    setCourseFund(null);
    setRewardToken(null);
    setEnvError('');
  };

  const triggerRefresh = (payload) => {
    const maybeId = payload?.createdId;
    try {
      if (typeof maybeId === 'bigint') setCreatedCampaignHint(maybeId);
      else if (maybeId != null) setCreatedCampaignHint(BigInt(maybeId));
    } catch {
      // ignore
    }
    setRefreshNonce((n) => n + 1);
  };

  return (
    <div className="container">
      <header className="header">
        <div>
          <h1 className="h1">CourseFund</h1>
          <p className="muted">Crowdfund campaigns with Sepolia ETH and earn reward tokens.</p>
        </div>
        <div className="pill">React + Vite + ethers v6</div>
      </header>

      <div className="twoCol section">
        <section className="card">
          <div className="row space-between">
            <h2 className="h2">Getting started</h2>
            <span className="badge">
              <span className={`dot ${isConnected ? 'ok' : ''}`} />
              {isConnected ? 'Wallet connected' : 'Not connected'}
            </span>
          </div>

          <div className="mt" />
          <ol className="muted" style={{ margin: 0, paddingLeft: 18 }}>
            <li>Install MetaMask and switch network to Sepolia.</li>
            <li>Get some Sepolia ETH from a faucet.</li>
            <li>Connect wallet, then create a campaign or donate to one.</li>
            <li>After donating, check your Reward Token balance.</li>
          </ol>

          <div className="mt" />
          <div className="muted">
            Tip: this UI can show a demo preview while you wire ABIs/addresses.
          </div>
        </section>

        <Wallet connection={connection} onConnected={onConnected} onDisconnected={onDisconnected} />
      </div>

      {!hasAddresses ? <EnvNotice /> : null}
      {envError ? <div className="card error">{envError}</div> : null}

      {hasAddresses ? (
        <div className="section">
          <ContractSettings />
        </div>
      ) : null}

      {isConnected ? (
        <>
          <div className="section">
            <BalancePanel provider={connection.provider} rewardToken={rewardToken} address={connection.address} />
          </div>
          <div className="section">
            <ContributionForm courseFund={courseFund} disabled={!courseFund} onDonated={triggerRefresh} />
          </div>
          <div className="section">
            <CreateCampaign courseFund={courseFund} disabled={!courseFund} onCreated={triggerRefresh} />
          </div>
          <div className="section">
            <CampaignList
              courseFund={courseFund}
              currentAccount={connection.address}
              refreshSignal={refreshNonce}
              createdCampaignHint={createdCampaignHint}
              demoMode={demoMode}
              demoCampaigns={demoCampaigns}
            />
          </div>
        </>
      ) : (
        <div className="section">
          <CampaignList
            courseFund={publicCourseFund}
            currentAccount={null}
            refreshSignal={0}
            createdCampaignHint={null}
            demoMode={demoMode}
            demoCampaigns={demoCampaigns}
          />
        </div>
      )}

      <footer className="footer">
        <div className="muted">
          No backend. Uses MetaMask + Sepolia.
        </div>
        <div className="tip mt-xs">
          Tip: Example courses are just a preview. Paste your ABIs + contract addresses to make everything fully on-chain.
        </div>
      </footer>
    </div>
  );
}
