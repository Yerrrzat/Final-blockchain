import { useEffect, useMemo, useState } from 'react';
import { ethers } from 'ethers';

import { formatEth, getSepoliaAddressUrl } from '../web3/provider';
import { getErc20Metadata } from '../web3/contracts';

export default function BalancePanel({ provider, rewardToken, address }) {
  const [ethBalance, setEthBalance] = useState(null);
  const [tokenBalance, setTokenBalance] = useState(null);
  const [tokenMeta, setTokenMeta] = useState({ symbol: 'TOKEN', decimals: 18 });
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);

  const canLoad = useMemo(() => Boolean(provider && address), [provider, address]);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (!canLoad) return;

      setError('');

      try {
        const [ethWei, meta] = await Promise.all([
          provider.getBalance(address),
          getErc20Metadata(rewardToken),
        ]);

        if (cancelled) return;

        setEthBalance(ethWei);
        setTokenMeta(meta);
        setLastUpdated(new Date());
      } catch (e) {
        if (cancelled) return;
        setError(e?.message ?? String(e));
      }

      try {
        if (typeof rewardToken?.balanceOf === 'function') {
          const bal = await rewardToken.balanceOf(address);
          if (!cancelled) setTokenBalance(bal);
        }
      } catch {
        if (!cancelled) setTokenBalance(null);
      }
    }

    load();

    const interval = setInterval(load, 12_000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [canLoad, provider, rewardToken, address]);

  const ethFormatted = ethBalance == null ? '-' : `${formatEth(ethBalance)} ETH`;

  const tokenFormatted = useMemo(() => {
    if (tokenBalance == null) return '-';
    try {
      return `${ethers.formatUnits(tokenBalance, tokenMeta.decimals)} ${tokenMeta.symbol}`;
    } catch {
      return `${tokenBalance.toString()} ${tokenMeta.symbol}`;
    }
  }, [tokenBalance, tokenMeta.decimals, tokenMeta.symbol]);

  return (
    <section className="card">
      <div className="row space-between">
        <h2 className="h2">Balances</h2>
        <div className="row">
          {lastUpdated ? <span className="muted">Updated: {lastUpdated.toLocaleTimeString()}</span> : null}
          {address ? (
            <a className="link" href={getSepoliaAddressUrl(address)} target="_blank" rel="noreferrer">
              Etherscan
            </a>
          ) : null}
        </div>
      </div>

      <div className="grid3 mt">
        <div>
          <div className="label">ETH</div>
          <div className="mono">{ethFormatted}</div>
        </div>
        <div>
          <div className="label">CRT Rewards</div>
          <div className="mono">{tokenFormatted}</div>
        </div>
        <div>
          <div className="label">Wallet</div>
          <div className="mono">{address ?? '-'}</div>
        </div>
      </div>

      {error ? <div className="error mt">{error}</div> : null}
    </section>
  );
}
