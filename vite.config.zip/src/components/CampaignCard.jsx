import { useEffect, useMemo, useState } from 'react';
import { ethers } from 'ethers';

import DonateForm from './DonateForm';
import { getSepoliaAddressUrl } from '../web3/provider';
import { getUserContribution } from '../web3/contracts';

function formatDeadline(deadline) {
  if (deadline == null) return '-';

  const d = typeof deadline === 'bigint' ? deadline : BigInt(deadline);

  // if contract stores ms, convert
  const seconds = d > 10_000_000_000n ? d / 1000n : d;
  const ms = Number(seconds) * 1000;

  if (!Number.isFinite(ms)) return seconds.toString();
  return new Date(ms).toLocaleString();
}

function getSeconds(deadline) {
  if (deadline == null) return null;
  const d = typeof deadline === 'bigint' ? deadline : BigInt(deadline);
  const seconds = d > 10_000_000_000n ? d / 1000n : d;
  return seconds;
}

function formatTimeLeft(deadline) {
  const seconds = getSeconds(deadline);
  if (seconds == null) return '-';
  const now = BigInt(Math.floor(Date.now() / 1000));
  const diff = seconds - now;
  if (diff <= 0n) return 'Ended';

  const days = diff / 86400n;
  const hours = (diff % 86400n) / 3600n;
  if (days > 0n) return `${days}d ${hours}h left`;
  const mins = (diff % 3600n) / 60n;
  if (hours > 0n) return `${hours}h ${mins}m left`;
  return `${mins}m left`;
}

export default function CampaignCard({ campaign, courseFund, currentAccount, onRefresh, readOnly = false }) {
  const [contribution, setContribution] = useState(null);

  const goalEth = useMemo(() => ethers.formatEther(campaign.goal ?? 0n), [campaign.goal]);
  const raisedEth = useMemo(() => ethers.formatEther(campaign.raised ?? 0n), [campaign.raised]);

  const progress = useMemo(() => {
    const goal = campaign.goal ?? 0n;
    const raised = campaign.raised ?? 0n;
    if (!goal) return 0;
    const pct = Number((raised * 10000n) / goal) / 100;
    return Math.max(0, Math.min(100, Number.isFinite(pct) ? pct : 0));
  }, [campaign.goal, campaign.raised]);

  const timeLeft = useMemo(() => formatTimeLeft(campaign.deadline), [campaign.deadline]);

  const statusText = useMemo(() => {
    if (campaign.finalized === true) return campaign.success ? 'Finalized: Success' : 'Finalized: Failed';
    if (campaign.finalized === false) return 'Active';
    return null;
  }, [campaign.finalized, campaign.success]);

  useEffect(() => {
    let cancelled = false;

    async function loadContribution() {
      if (readOnly) {
        setContribution(null);
        return;
      }

      if (!currentAccount) {
        setContribution(null);
        return;
      }

      if (!courseFund) {
        setContribution(null);
        return;
      }

      try {
        const v = await getUserContribution(courseFund, {
          campaignId: campaign.id,
          userAddress: currentAccount,
        });
        if (!cancelled) setContribution(v);
      } catch {
        if (!cancelled) setContribution(null);
      }
    }

    loadContribution();
    return () => {
      cancelled = true;
    };
  }, [readOnly, courseFund, campaign.id, currentAccount]);

  return (
    <article className="card">
      <div className="row space-between">
        <h3 className="h3">{campaign.title || `Campaign #${campaign.id.toString()}`}</h3>
        <div className="row" style={{ flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {statusText ? (
            <span className="badge">
              <span className={`dot ${statusText.includes('Failed') ? 'warn' : 'ok'}`} /> {statusText}
            </span>
          ) : null}
          <span className="badge">
            <span className={`dot ${timeLeft === 'Ended' ? 'warn' : 'ok'}`} /> {timeLeft}
          </span>
        </div>
      </div>

      {campaign.summary ? (
        <p className="muted mt">{campaign.summary}</p>
      ) : null}

      {campaign.level || (Array.isArray(campaign.perks) && campaign.perks.length) ? (
        <div className="mt">
          <div className="row" style={{ flexWrap: 'wrap' }}>
            {campaign.level ? <span className="badge"><span className="dot" /> {campaign.level}</span> : null}
            {Array.isArray(campaign.perks) ? campaign.perks.slice(0, 3).map((p) => (
              <span key={p} className="badge"><span className="dot ok" /> {p}</span>
            )) : null}
          </div>
        </div>
      ) : null}

      <div className="mt">
        <div className="row space-between">
          <div className="muted">Progress</div>
          <div className="mono">{progress.toFixed(2)}%</div>
        </div>
        <div className="progress mt-xs">
          <div style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="grid3 mt">
        <div>
          <div className="label">Goal</div>
          <div className="mono">{goalEth} ETH</div>
        </div>
        <div>
          <div className="label">Raised</div>
          <div className="mono">{raisedEth} ETH</div>
        </div>
        <div>
          <div className="label">Deadline</div>
          <div className="mono">{formatDeadline(campaign.deadline)}</div>
        </div>
      </div>

      <div className="grid2 mt">
        <div>
          <div className="label">Creator</div>
          {campaign.creator ? (
            <a className="link mono" href={getSepoliaAddressUrl(campaign.creator)} target="_blank" rel="noreferrer">
              {campaign.creator}
            </a>
          ) : (
            <div className="mono">-</div>
          )}
        </div>
        <div>
          <div className="label">Your contribution</div>
          <div className="mono">
            {contribution == null ? '-' : `${ethers.formatEther(contribution)} ETH`}
          </div>
        </div>
      </div>

      <div className="mt">
        <div className="label">Donate</div>
        {readOnly ? (
          <div className="muted">Read-only. Connect wallet to donate on Sepolia.</div>
        ) : (
          <>
            <DonateForm
              courseFund={courseFund}
              campaignId={campaign.id}
              disabled={!courseFund || !currentAccount}
              onDonated={onRefresh}
            />
            {!courseFund ? <div className="muted mt-xs">Connect wallet to donate on Sepolia.</div> : null}
          </>
        )}
      </div>
    </article>
  );
}
