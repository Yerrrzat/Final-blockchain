import { useCallback, useEffect, useMemo, useState } from 'react';

import CampaignCard from './CampaignCard';
import { fetchCampaignById, fetchCampaigns } from '../web3/contracts';

export default function CampaignList({
  courseFund,
  currentAccount,
  refreshSignal,
  createdCampaignHint,
  demoMode = false,
  demoCampaigns = [],
}) {
  const [campaigns, setCampaigns] = useState([]);
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState('');
  const [examplesOpen, setExamplesOpen] = useState(false);

  const showExamples = demoMode && examplesOpen && Array.isArray(demoCampaigns) && demoCampaigns.length > 0;
  const isReadOnly = Boolean(courseFund) && !currentAccount;

  const effectiveCampaigns = useMemo(() => {
    if (courseFund) return campaigns;
    if (!showExamples) return [];
    return demoCampaigns;
  }, [courseFund, campaigns, showExamples, demoCampaigns]);

  const refresh = useCallback(async () => {
    if (!courseFund) return;

    setError('');
    setStatus('loading');

    try {
      const list = await fetchCampaigns(courseFund);

      let merged = list;
      if (createdCampaignHint != null) {
        const created = await fetchCampaignById(courseFund, createdCampaignHint);
        if (created && !list.some((c) => c.id === created.id)) {
          merged = [created, ...list];
        }
      }

      setCampaigns(merged);
      setStatus('idle');
    } catch (e) {
      // Even if enumeration fails, try to show the just-created campaign by id.
      if (createdCampaignHint != null) {
        try {
          const created = await fetchCampaignById(courseFund, createdCampaignHint);
          if (created) {
            setCampaigns([created]);
          }
        } catch {
          // ignore
        }
      }

      setStatus('idle');
      setError(e?.message ?? String(e));
    }
  }, [courseFund, createdCampaignHint]);

  useEffect(() => {
    refresh();
  }, [refresh, courseFund, currentAccount, refreshSignal]);

  return (
    <section>
      <div className="row space-between">
        <h2 className="h2">Campaigns</h2>
        <div className="row">
          {demoMode ? <span className="badge"><span className="dot warn" /> Examples</span> : null}
          {demoMode ? (
            <button
              className="btn secondary"
              type="button"
              onClick={() => setExamplesOpen((v) => !v)}
            >
              {examplesOpen ? 'Hide example courses' : 'Show example courses'}
            </button>
          ) : null}
          <button className="btn secondary" onClick={refresh} disabled={!courseFund || status === 'loading'}>
            {status === 'loading' ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>
      </div>

      {error ? <div className="error mt">{error}</div> : null}

      {isReadOnly ? (
        <div className="card mt">
          <div className="row space-between">
            <div>
              <div className="label">Read-only mode</div>
              <div className="muted">Campaigns are loaded from Sepolia. Connect your wallet to create or donate.</div>
            </div>
            <span className="badge"><span className="dot" /> Public</span>
          </div>
        </div>
      ) : null}

      {!courseFund ? (
        <div className="card mt">
          <div className="row space-between">
            <div>
              <div className="label">Not connected</div>
              <div className="muted">Connect your wallet to load real campaigns from Sepolia.</div>
            </div>
            {demoMode ? null : null}
          </div>

          {demoMode ? (
            <div className="muted mt">
              Examples are UI-only preview (no transactions). Toggle them if you want to see how the app looks with data.
            </div>
          ) : null}
        </div>
      ) : effectiveCampaigns.length === 0 ? (
        <div className="card mt">
          <div className="muted">No campaigns found on-chain yet.</div>
        </div>
      ) : null}

      {effectiveCampaigns.length > 0 ? (
        <div className="stack mt">
          {effectiveCampaigns.map((c) => (
            <CampaignCard
              key={c.id.toString()}
              campaign={c}
              courseFund={courseFund}
              currentAccount={currentAccount}
              onRefresh={refresh}
              readOnly={isReadOnly}
            />
          ))}
        </div>
      ) : null}

      {courseFund && showExamples ? (
        <div className="mt">
          <div className="row space-between">
            <h3 className="h3">Example courses (preview)</h3>
            <span className="badge"><span className="dot warn" /> UI-only</span>
          </div>
          <div className="muted mt-xs">These are not on-chain and can’t be donated to.</div>
          <div className="stack mt">
            {demoCampaigns.map((c) => (
              <CampaignCard
                key={`example-${c.id.toString()}`}
                campaign={c}
                courseFund={null}
                currentAccount={null}
                onRefresh={() => {}}
                readOnly
              />
            ))}
          </div>
        </div>
      ) : null}
    </section>
  );
}
