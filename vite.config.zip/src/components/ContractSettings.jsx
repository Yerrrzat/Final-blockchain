import { useMemo, useState } from 'react';

const STORAGE_KEYS = {
  courseFund: 'coursefund.addressOverride',
  rewardToken: 'rewardtoken.addressOverride',
};

function safeGet(key) {
  try {
    return window.localStorage.getItem(key) || '';
  } catch {
    return '';
  }
}

function safeSet(key, value) {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // ignore
  }
}

function safeRemove(key) {
  try {
    window.localStorage.removeItem(key);
  } catch {
    // ignore
  }
}

export default function ContractSettings() {
  const envCourseFund = import.meta.env.VITE_COURSEFUND_ADDRESS || '';
  const envRewardToken = import.meta.env.VITE_REWARDTOKEN_ADDRESS || '';

  const [courseFund, setCourseFund] = useState(() => safeGet(STORAGE_KEYS.courseFund) || envCourseFund);
  const [rewardToken, setRewardToken] = useState(() => safeGet(STORAGE_KEYS.rewardToken) || envRewardToken);

  const hasOverrides = useMemo(() => {
    return Boolean(safeGet(STORAGE_KEYS.courseFund) || safeGet(STORAGE_KEYS.rewardToken));
  }, []);

  const onSave = () => {
    const cf = String(courseFund || '').trim();
    const rt = String(rewardToken || '').trim();

    if (cf) safeSet(STORAGE_KEYS.courseFund, cf);
    else safeRemove(STORAGE_KEYS.courseFund);

    if (rt) safeSet(STORAGE_KEYS.rewardToken, rt);
    else safeRemove(STORAGE_KEYS.rewardToken);

    window.location.reload();
  };

  const onUseEnv = () => {
    safeRemove(STORAGE_KEYS.courseFund);
    safeRemove(STORAGE_KEYS.rewardToken);
    setCourseFund(envCourseFund);
    setRewardToken(envRewardToken);
    window.location.reload();
  };

  return (
    <div className="card">
      <div className="row space-between">
        <div>
          <div className="h2" style={{ marginBottom: 4 }}>Contract settings</div>
          <div className="muted">
            Frontend-only fix: paste the real deployed addresses here (saved in your browser).
          </div>
        </div>
        {hasOverrides ? <span className="badge">Overrides active</span> : <span className="badge">Using .env</span>}
      </div>

      <div className="mt" />

      <div className="grid" style={{ gap: 10 }}>
        <label className="field">
          <span className="label">CourseFund address</span>
          <input
            className="input mono"
            value={courseFund}
            onChange={(e) => setCourseFund(e.target.value)}
            placeholder={envCourseFund || '0x...'}
          />
        </label>

        <label className="field">
          <span className="label">RewardToken address</span>
          <input
            className="input mono"
            value={rewardToken}
            onChange={(e) => setRewardToken(e.target.value)}
            placeholder={envRewardToken || '0x...'}
          />
        </label>
      </div>

      <div className="mt" />
      <div className="row" style={{ gap: 10, flexWrap: 'wrap' }}>
        <button className="btn" onClick={onSave}>Save & reload</button>
        <button className="btn secondary" onClick={onUseEnv}>Clear overrides (use .env)</button>
      </div>

      <div className="mt" />
      <div className="muted">
        Note: if the address is wrong, transactions can still confirm but won’t create campaigns (no events/state).
      </div>
    </div>
  );
}
