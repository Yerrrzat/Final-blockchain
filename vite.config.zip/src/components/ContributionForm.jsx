import { useMemo, useState } from 'react';
import { ethers } from 'ethers';

import { donate } from '../web3/contracts';

export default function ContributionForm({ courseFund, disabled, onDonated }) {
  const [campaignId, setCampaignId] = useState('1');
  const [amountEth, setAmountEth] = useState('0.01');
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState('');

  const busy = useMemo(() => status === 'signing' || status === 'pending', [status]);

  const onSubmit = async () => {
    setError('');

    try {
      if (!courseFund) throw new Error('CourseFund contract not ready');

      if (!campaignId || Number(campaignId) <= 0) {
        throw new Error('Enter a valid campaign ID.');
      }
      if (!amountEth || Number(amountEth) <= 0) {
        throw new Error('Enter a valid ETH amount.');
      }

      const id = BigInt(campaignId);
      const amountWei = ethers.parseEther(amountEth);

      setStatus('signing');
      const tx = await donate(courseFund, { campaignId: id, amountWei });

      setStatus('pending');
      await tx.wait();
      setStatus('confirmed');
      alert('Transaction confirmed on Sepolia.');
      onDonated?.();

      setTimeout(() => setStatus('idle'), 1500);
    } catch (e) {
      setStatus('idle');
      setError(e?.shortMessage ?? e?.message ?? String(e));
    }
  };

  return (
    <section className="card">
      <div className="row space-between">
        <h2 className="h2">Campaign Contribution</h2>
        <span className="badge">CourseFund.contribute</span>
      </div>

      <div className="form mt">
        <div className="field">
          <label className="label" htmlFor="campaignId">Campaign ID</label>
          <input
            id="campaignId"
            value={campaignId}
            onChange={(e) => setCampaignId(e.target.value)}
            placeholder="1"
            inputMode="numeric"
          />
        </div>
        <div className="field">
          <label className="label" htmlFor="amountEth">Amount (ETH)</label>
          <input
            id="amountEth"
            value={amountEth}
            onChange={(e) => setAmountEth(e.target.value)}
            placeholder="0.01"
            inputMode="decimal"
          />
        </div>
        <button className="btn" onClick={onSubmit} disabled={disabled || busy}>
          {status === 'signing' ? 'Confirm in MetaMask...' : status === 'pending' ? 'Sending...' : 'Send ETH'}
        </button>
        {status === 'confirmed' ? <span className="ok">Confirmed</span> : null}
        {error ? <div className="error mt-xs">{error}</div> : null}
      </div>
    </section>
  );
}
