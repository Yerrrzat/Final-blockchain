import { useState } from 'react';
import { ethers } from 'ethers';

import { createCampaign, findCampaignIdByTitle } from '../web3/contracts';
import { getSepoliaTxUrl } from '../web3/provider';

export default function CreateCampaign({ courseFund, disabled, onCreated }) {
  const [title, setTitle] = useState('');
  const [goalEth, setGoalEth] = useState('0.1');
  const [durationDays, setDurationDays] = useState(7);

  const [status, setStatus] = useState('idle');
  const [txHash, setTxHash] = useState('');
  const [error, setError] = useState('');

  const onSubmit = async (e) => {
    e.preventDefault();

    setError('');
    setTxHash('');

    try {
      if (!courseFund) throw new Error('CourseFund contract not ready');
      if (!title.trim()) throw new Error('Title is required');
      if (!goalEth || Number(goalEth) <= 0) throw new Error('Goal must be > 0');
      if (!durationDays || Number(durationDays) < 1) throw new Error('Duration must be at least 1 day');

      const goalWei = ethers.parseEther(String(goalEth));

      setStatus('signing');
      const tx = await createCampaign(courseFund, {
        title: title.trim(),
        goalWei,
        durationDays,
      });

      setTxHash(tx.hash);
      setStatus('pending');
      const receipt = await tx.wait();
      setStatus('confirmed');

      let createdId = null;
      try {
        const contractAddress = String(courseFund?.target ?? '').toLowerCase();
        for (const log of receipt?.logs ?? []) {
          if (contractAddress && String(log?.address ?? '').toLowerCase() !== contractAddress) continue;
          try {
            const parsed = courseFund.interface.parseLog(log);
            if (parsed?.name === 'CampaignCreated') {
              createdId = parsed?.args?.id ?? parsed?.args?.campaignId ?? parsed?.args?.[0] ?? null;
              break;
            }
          } catch {
            // not our event
          }
        }
      } catch {
        // ignore
      }

      // Fallback: if we couldn't parse the event (ABI mismatch / no event),
      // try to infer the campaign ID by scanning on-chain state.
      if (createdId == null) {
        try {
          createdId = await findCampaignIdByTitle(courseFund, title);
        } catch {
          // ignore
        }
      }

      setTitle('');
      onCreated?.({ createdId });

      setTimeout(() => setStatus('idle'), 2000);
    } catch (e2) {
      setStatus('idle');
      setError(e2?.shortMessage ?? e2?.message ?? String(e2));
    }
  };

  return (
    <section className="card">
      <div className="row space-between">
        <h2 className="h2">Create Campaign</h2>
        <span className="badge"><span className="dot" /> Sepolia</span>
      </div>

      <form className="form mt" onSubmit={onSubmit}>
        <label className="field">
          <span className="label">Title</span>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Example: Frontend for DApps (React + ethers)"
            maxLength={64}
          />
          <span className="muted">Give your campaign a clear name (max 64 chars).</span>
        </label>

        <div className="grid2">
          <label className="field">
            <span className="label">Goal (ETH)</span>
            <input
              type="number"
              min="0.0001"
              step="0.0001"
              value={goalEth}
              onChange={(e) => setGoalEth(e.target.value)}
              placeholder="0.5"
            />
            <span className="muted">Total amount to raise (Sepolia ETH).</span>
          </label>

          <label className="field">
            <span className="label">Duration (days)</span>
            <input
              type="number"
              min={1}
              value={durationDays}
              onChange={(e) => setDurationDays(Number(e.target.value))}
            />
            <span className="muted">Deadline is computed from now.</span>
          </label>
        </div>

        <div className="row">
          <button className="btn" type="submit" disabled={disabled || status === 'signing' || status === 'pending'}>
            {status === 'signing' ? 'Confirm in MetaMask...' : status === 'pending' ? 'Creating...' : 'Create Campaign'}
          </button>

          {txHash ? (
            <a className="link" href={getSepoliaTxUrl(txHash)} target="_blank" rel="noreferrer">
              Tx: {txHash.slice(0, 10)}...
            </a>
          ) : null}

          {status === 'confirmed' ? <span className="ok">Created</span> : null}
        </div>
      </form>

      {error ? <div className="error mt">{error}</div> : null}
      <div className="muted mt">If your contract uses different function names, update `src/web3/contracts.js`.</div>
    </section>
  );
}
