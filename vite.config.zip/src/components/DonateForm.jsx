import { useMemo, useState } from 'react';
import { ethers } from 'ethers';

import { donate } from '../web3/contracts';
import { getSepoliaTxUrl } from '../web3/provider';

export default function DonateForm({ courseFund, campaignId, disabled, onDonated }) {
  const [amountEth, setAmountEth] = useState('0.01');
  const [status, setStatus] = useState('idle');
  const [txHash, setTxHash] = useState('');
  const [error, setError] = useState('');

  const busy = useMemo(() => status === 'signing' || status === 'pending', [status]);

  const onDonate = async () => {
    setError('');
    setTxHash('');

    try {
      if (!courseFund) throw new Error('CourseFund contract not ready');

      const amountWei = ethers.parseEther(amountEth);

      setStatus('signing');
      const tx = await donate(courseFund, { campaignId, amountWei });

      setTxHash(tx.hash);
      setStatus('pending');
      await tx.wait();
      setStatus('confirmed');
      alert('Transaction confirmed on Sepolia.');
      onDonated?.();

      setTimeout(() => setStatus('idle'), 1500);
    } catch (e) {
      setStatus('idle');
      setError(e?.shortMessage ?? e?.message ?? String(e));
    }
  };

  return (
    <div className="donate">
      <input className="input" value={amountEth} onChange={(e) => setAmountEth(e.target.value)} placeholder="0.01" />
      <button className="btn" onClick={onDonate} disabled={disabled || busy}>
        {status === 'signing' ? 'Confirm...' : status === 'pending' ? 'Sending...' : 'Donate'}
      </button>

      {txHash ? (
        <a className="link" href={getSepoliaTxUrl(txHash)} target="_blank" rel="noreferrer">
          Tx
        </a>
      ) : null}

      {status === 'confirmed' ? <span className="ok">Done</span> : null}
      {error ? <div className="error mt-xs">{error}</div> : null}
    </div>
  );
}
