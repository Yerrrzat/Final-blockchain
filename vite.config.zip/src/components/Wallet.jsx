import { useEffect, useMemo, useState } from 'react';

import {
  connectWallet,
  getBrowserProvider,
  getEthBalance,
  hasInjectedProvider,
  formatEth,
  isSepolia,
  shortAddress,
} from '../web3/provider';

export default function Wallet({ onConnected, onDisconnected, connection }) {
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState('');
  const [ethBalance, setEthBalance] = useState(null);
  const [copied, setCopied] = useState(false);

  const isConnected = Boolean(connection?.address);
  const wrongNetwork = useMemo(() => {
    if (!connection?.chainId) return false;
    return !isSepolia(connection.chainId);
  }, [connection?.chainId]);

  const copyAddress = async () => {
    if (!connection?.address) return;
    try {
      await navigator.clipboard.writeText(connection.address);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    let cancelled = false;

    async function loadBalance() {
      if (!connection?.provider || !connection?.address) {
        setEthBalance(null);
        return;
      }

      try {
        const bal = await getEthBalance(connection.provider, connection.address);
        if (!cancelled) setEthBalance(bal);
      } catch {
        if (!cancelled) setEthBalance(null);
      }
    }

    loadBalance();
    return () => {
      cancelled = true;
    };
  }, [connection?.provider, connection?.address]);

  useEffect(() => {
    if (!hasInjectedProvider()) return undefined;

    const ethereum = window.ethereum;

    const handleAccountsChanged = (accounts) => {
      if (!accounts?.length) {
        onDisconnected?.();
        return;
      }
      // easiest: reload connection state via provider
      (async () => {
        try {
          const provider = await getBrowserProvider();
          const signer = await provider.getSigner();
          const address = await signer.getAddress();
          const network = await provider.getNetwork();
          onConnected?.({ provider, signer, address, chainId: network.chainId, networkName: network.name });
        } catch {
          // ignore
        }
      })();
    };

    const handleChainChanged = () => {
      // MetaMask recommends full reload on chain change
      window.location.reload();
    };

    ethereum.on('accountsChanged', handleAccountsChanged);
    ethereum.on('chainChanged', handleChainChanged);

    return () => {
      ethereum.removeListener('accountsChanged', handleAccountsChanged);
      ethereum.removeListener('chainChanged', handleChainChanged);
    };
  }, [onConnected, onDisconnected]);

  const onConnectClick = async () => {
    setError('');

    try {
      setStatus('connecting');
      const conn = await connectWallet();
      onConnected?.(conn);
      setStatus('idle');
    } catch (e) {
      setStatus('idle');
      setError(e?.message ?? String(e));
    }
  };

  return (
    <section className="card">
      <div className="row space-between">
        <div>
          <h2 className="h2">Wallet</h2>
          {!hasInjectedProvider() ? (
            <p className="muted">MetaMask not detected. Install MetaMask to use this DApp.</p>
          ) : isConnected ? (
            <p className="muted">
              Connected: <span className="mono">{shortAddress(connection.address)}</span>
            </p>
          ) : (
            <p className="muted">Connect MetaMask to begin.</p>
          )}
        </div>

        <div className="row">
          {!isConnected ? (
            <button className="btn" onClick={onConnectClick} disabled={!hasInjectedProvider() || status === 'connecting'}>
              {status === 'connecting' ? 'Connecting...' : 'Connect MetaMask'}
            </button>
          ) : (
            <>
              <span className="badge">
                <span className={`dot ${wrongNetwork ? 'warn' : 'ok'}`} />
                {wrongNetwork ? 'Wrong network' : 'Sepolia ready'}
              </span>
              <button className="btn secondary" onClick={onDisconnected}>
                Disconnect
              </button>
            </>
          )}
        </div>
      </div>

      {isConnected ? (
        <div className="grid2 mt">
          <div>
            <div className="label">Address</div>
            <div className="row" style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div className="mono" title={connection.address}>{connection.address}</div>
              <button className="btn secondary" type="button" onClick={copyAddress}>
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>
          <div>
            <div className="label">Network</div>
            <div>
              {connection.networkName ?? 'Unknown'} (chainId: <span className="mono">{String(connection.chainId)}</span>)
            </div>
            {wrongNetwork ? <div className="warn mt-xs">Wrong network. Please switch to Sepolia.</div> : null}
          </div>
          <div>
            <div className="label">SepoliaETH Balance</div>
            <div className="mono">{ethBalance == null ? '-' : `${formatEth(ethBalance)} ETH`}</div>
            <div className="muted">{isConnected ? `Account: ${shortAddress(connection.address)}` : ''}</div>
          </div>
        </div>
      ) : null}

      {error ? <div className="error mt">{error}</div> : null}
    </section>
  );
}
