import { ethers } from 'ethers';

import CourseFundArtifact from '../abis/CourseFund.json';
import RewardTokenArtifact from '../abis/RewardToken.json';

const STORAGE_KEYS = {
  courseFund: 'coursefund.addressOverride',
  rewardToken: 'rewardtoken.addressOverride',
};

function normalizeAbi(maybeArtifact) {
  return maybeArtifact?.abi ?? maybeArtifact;
}

function getLocalStorageItem(key) {
  try {
    if (typeof window === 'undefined') return null;
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function getConfiguredAddress(envKey, storageKey) {
  const override = getLocalStorageItem(storageKey);
  const value = override || import.meta.env[envKey];
  if (!value) {
    throw new Error(`Missing ${envKey} in .env (or override not set)`);
  }
  if (!ethers.isAddress(value)) {
    throw new Error(`${envKey} is not a valid address: ${value}`);
  }
  return value;
}

export function hasConfiguredAddresses() {
  const cf = getLocalStorageItem(STORAGE_KEYS.courseFund) || import.meta.env.VITE_COURSEFUND_ADDRESS;
  const rt = getLocalStorageItem(STORAGE_KEYS.rewardToken) || import.meta.env.VITE_REWARDTOKEN_ADDRESS;
  return Boolean(cf && rt);
}

export function getCourseFundAddress() {
  return getConfiguredAddress('VITE_COURSEFUND_ADDRESS', STORAGE_KEYS.courseFund);
}

export function getRewardTokenAddress() {
  return getConfiguredAddress('VITE_REWARDTOKEN_ADDRESS', STORAGE_KEYS.rewardToken);
}

export async function getDeployedFunctionSelectors(provider, address) {
  if (!provider || !address) return new Set();
  try {
    const code = await provider.getCode(address);
    const hex = String(code ?? '0x');
    if (!hex || hex === '0x') return new Set();
    const body = hex.startsWith('0x') ? hex.slice(2) : hex;

    const selectors = new Set();
    for (let i = 0; i < body.length - 10; i += 2) {
      // PUSH4 <selector>
      if (body.slice(i, i + 2) === '63') {
        selectors.add(`0x${body.slice(i + 2, i + 10)}`);
      }
    }
    return selectors;
  } catch {
    return new Set();
  }
}

export async function validateCourseFundDeployment(provider) {
  const address = getCourseFundAddress();
  if (!provider) {
    // Can't validate without a provider; treat as "unknown" rather than blocking.
    return true;
  }

  // 1) Contract must exist.
  const code = await provider.getCode(address);
  if (!code || code === '0x') {
    throw new Error(
      `VITE_COURSEFUND_ADDRESS (${address}) has no code on Sepolia (EOA or not deployed). ` +
        'Update .env with the real CourseFund contract address you deployed on Sepolia.',
    );
  }

  // 2) Avoid false negatives for proxies: prefer functional validation via read calls.
  // If any of these calls returns non-empty data, it's very likely the right contract.
  const count = await tryRawUint256Calls(providerLike(address, provider), [
    'campaignCount()',
    'getCampaignCount()',
    'campaignsCount()',
    'totalCampaigns()',
    'getCampaignsCount()',
  ]);

  if (count != null) return true;

  const getterSignatures = [
    'campaigns(uint256)',
    'campaign(uint256)',
    'getCampaign(uint256)',
    'getCampaignById(uint256)',
  ];

  const getterOk = await tryRawExistsCall(provider, address, getterSignatures, 0n);
  if (getterOk) return true;

  // 3) As a final hint, do a lightweight selector scan (useful, but not authoritative).
  const selectors = await getDeployedFunctionSelectors(provider, address);
  const expected = ethers.id('createCampaign(string,uint256,uint256)').slice(0, 10);
  const alsoHasErc20 = selectors.has('0x70a08231') && selectors.has('0xa9059cbb');
  const extra = alsoHasErc20 ? ' It looks like an ERC20/faucet-style contract (has balanceOf/transfer).' : '';

  throw new Error(
    `VITE_COURSEFUND_ADDRESS (${address}) does not respond to common CourseFund read methods (count/getter).${extra} ` +
      `If this is a proxy, ensure the proxy points to your CourseFund implementation. ` +
      'Update .env with the real CourseFund contract address you deployed on Sepolia.',
  );
}

function providerLike(targetAddress, provider) {
  // Minimal adapter so we can reuse tryRawUint256Calls() (expects a "contract-like" object)
  return { target: targetAddress, runner: provider };
}

async function tryRawExistsCall(provider, address, signatures, uintArg) {
  if (!provider || !address) return false;
  const coder = ethers.AbiCoder.defaultAbiCoder();
  const argData = coder.encode(['uint256'], [uintArg]);

  for (const signature of signatures) {
    const selector = ethers.id(signature).slice(0, 10);
    try {
      const result = await provider.call({ to: address, data: selector + argData.slice(2) });
      if (result && result !== '0x') return true;
    } catch {
      // ignore
    }
  }

  return false;
}

export function getCourseFundContract(signerOrProvider) {
  return new ethers.Contract(
    getCourseFundAddress(),
    normalizeAbi(CourseFundArtifact),
    signerOrProvider,
  );
}

export function getRewardTokenContract(signerOrProvider) {
  return new ethers.Contract(
    getRewardTokenAddress(),
    normalizeAbi(RewardTokenArtifact),
    signerOrProvider,
  );
}

function asBigInt(value, fallback = 0n) {
  try {
    if (typeof value === 'bigint') return value;
    if (typeof value === 'number') return BigInt(value);
    if (typeof value === 'string') return BigInt(value);
    if (value == null) return fallback;
    return BigInt(value);
  } catch {
    return fallback;
  }
}

function pick(raw, keys, indexFallback) {
  for (const key of keys) {
    if (raw && raw[key] != null) return raw[key];
  }
  if (Array.isArray(raw) && indexFallback != null) return raw[indexFallback];
  return undefined;
}

function isLikelyEmptyCampaign(c) {
  if (!c) return true;
  const titleEmpty = !c.title || String(c.title).trim().length === 0;
  const creatorEmpty = !c.creator || c.creator === ethers.ZeroAddress;
  const goalEmpty = (c.goal ?? 0n) === 0n;
  const deadlineEmpty = (c.deadline ?? 0n) === 0n;
  const raisedEmpty = (c.raised ?? 0n) === 0n;
  return titleEmpty && creatorEmpty && goalEmpty && deadlineEmpty && raisedEmpty;
}

function getRunnerProvider(contract) {
  const runner = contract?.runner;
  // ethers v6: runner can be a Provider or a Signer; signer has .provider
  return runner?.provider ?? runner;
}

async function tryRawUint256Calls(contract, signatures) {
  const provider = getRunnerProvider(contract);
  const address = contract?.target ?? (typeof contract?.getAddress === 'function' ? await contract.getAddress() : null);
  if (!provider || !address) return null;

  for (const signature of signatures) {
    const selector = ethers.id(signature).slice(0, 10);
    try {
      const result = await provider.call({ to: address, data: selector });
      if (!result || result === '0x') continue;
      return BigInt(result);
    } catch {
      // keep trying
    }
  }

  return null;
}

export function normalizeCampaign(raw, index) {
  // Supports your CourseFund struct ordering:
  // (creator, title, goal, deadline, totalFunded, finalized, success)
  const creator = pick(raw, ['creator', 'owner', 'author'], 0) ?? '';
  const title = pick(raw, ['title', 'name'], 1) ?? '';
  const goal = asBigInt(pick(raw, ['goal', 'target', 'amountGoal'], 2));
  const deadline = asBigInt(pick(raw, ['deadline', 'endAt', 'expiresAt'], 3));
  const raised = asBigInt(pick(raw, ['totalFunded', 'currentRaised', 'raised', 'amountRaised', 'pledged'], 4));
  const finalized = Boolean(pick(raw, ['finalized'], 5));
  const success = Boolean(pick(raw, ['success'], 6));
  const id = asBigInt(pick(raw, ['id', 'campaignId'], undefined), BigInt(index));

  return {
    id,
    title,
    goal,
    raised,
    deadline,
    creator,
    finalized,
    success,
    raw,
  };
}

async function sendFirst(contract, attempts) {
  let lastError;

  for (const attempt of attempts) {
    const fn = contract?.[attempt.name];
    if (typeof fn !== 'function') continue;

    try {
      return await fn(...attempt.args);
    } catch (err) {
      lastError = err;
    }
  }

  const available = contract?.interface?.fragments
    ?.filter((f) => f.type === 'function')
    ?.map((f) => f.format())
    ?.slice(0, 20);

  const hint = available?.length
    ? `Available functions (sample):\n- ${available.join('\n- ')}`
    : 'No ABI functions detected.';

  throw new Error(`No compatible contract method found. ${hint}\nLast error: ${lastError?.message ?? lastError}`);
}

export async function fetchCampaigns(courseFund) {
  if (!courseFund) return [];

  // Optional contracts expose a list function that returns an array of campaigns.
  const listFns = ['getAllCampaigns', 'getCampaigns'];
  for (const name of listFns) {
    if (typeof courseFund[name] === 'function') {
      try {
        const result = await courseFund[name]();
        if (Array.isArray(result)) {
          return result.map((c, i) => normalizeCampaign(c, i));
        }
      } catch {
        // keep trying
      }
    }
  }

  // Most minimal contracts expose a count method.
  const countFns = [
    'campaignCount',
    'campaignCounter',
    'campaignsCount',
    'getCampaignCount',
    'getTotalCampaigns',
    'numberOfCampaigns',
    'totalCampaigns',
  ];
  let count;
  for (const name of countFns) {
    if (typeof courseFund[name] === 'function') {
      try {
        count = asBigInt(await courseFund[name]());
        break;
      } catch {
        // keep trying
      }
    }
  }

  // If the ABI does not expose the count function name, try raw selectors.
  // This is important when createCampaign works, but campaign enumeration is missing.
  if (count == null) {
    const signatures = countFns.map((n) => `${n}()`);
    const rawCount = await tryRawUint256Calls(courseFund, signatures);
    if (rawCount != null) count = rawCount;
  }

  const itemFns = ['campaigns', 'getCampaign', 'campaignById'];
  async function readCampaignById(id) {
    for (const name of itemFns) {
      const fn = courseFund?.[name];
      if (typeof fn !== 'function') continue;
      try {
        return await fn(id);
      } catch {
        // keep trying
      }
    }
    return null;
  }

  // If no count, try deriving IDs from events (works for mapping-based storage).
  if (count == null && typeof courseFund.queryFilter === 'function') {
    try {
      const createdFilter = courseFund.filters?.CampaignCreated?.();
      if (createdFilter) {
        const logs = await courseFund.queryFilter(createdFilter);
        const ids = Array.from(
          new Set(
            logs
              .map((log) => asBigInt(log?.args?.id ?? log?.args?.campaignId ?? log?.args?.[0], null))
              .filter((v) => v != null)
              .map((v) => v.toString()),
          ),
        )
          .map((s) => BigInt(s))
          .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));

        const items = [];
        for (const id of ids) {
          const raw = await readCampaignById(id);
          if (raw != null) {
            items.push(normalizeCampaign(raw, Number(id)));
          } else {
            // As a last resort, build a partial item from the event args.
            const log = logs.find((l) => asBigInt(l?.args?.id ?? l?.args?.campaignId ?? l?.args?.[0], -1n) === id);
            const title = log?.args?.title ?? log?.args?.[1] ?? '';
            const goal = asBigInt(log?.args?.goal ?? log?.args?.[2], 0n);
            const deadline = asBigInt(log?.args?.deadline ?? log?.args?.[3], 0n);
            items.push(
              normalizeCampaign(
                {
                  creator: ethers.ZeroAddress,
                  title,
                  goal,
                  deadline,
                  totalFunded: 0n,
                  finalized: false,
                  success: false,
                  id,
                },
                Number(id),
              ),
            );
          }
        }

        return items;
      }
    } catch {
      // ignore and continue to probing
    }
  }

  // If we have a count, read 0..count-1.
  if (count != null) {
    // Different deployments may use 0-based IDs (0..count-1),
    // 1-based IDs (1..count), or even store lastId in `campaignCount`.
    let start = 0n;

    try {
      const raw0 = await readCampaignById(0n);
      if (raw0 == null || isLikelyEmptyCampaign(normalizeCampaign(raw0, 0))) {
        start = 1n;
      }
    } catch {
      start = 1n;
    }

    const items = [];
    for (let i = start; i <= count; i++) {
      const raw = await readCampaignById(i);

      // If the first candidate is missing, try the next id (helps 1-based with strict getters).
      if (raw == null) {
        if (i === start) continue;
        break;
      }

      const normalized = normalizeCampaign(raw, Number(i));
      if (isLikelyEmptyCampaign(normalized)) continue;
      items.push(normalized);
    }

    return items;
  }

  // Final fallback: sequential scan until we hit a run of empty slots.
  // This avoids the old fixed 0..49 probe which breaks once IDs exceed 50.
  const items = [];
  let start = 0n;
  try {
    const raw0 = await readCampaignById(0n);
    if (raw0 == null || isLikelyEmptyCampaign(normalizeCampaign(raw0, 0))) start = 1n;
  } catch {
    start = 1n;
  }

  const maxScan = 2000n;
  const maxEmptyStreak = 10;
  let emptyStreak = 0;

  for (let i = start; i < maxScan && emptyStreak < maxEmptyStreak; i++) {
    const raw = await readCampaignById(i);
    if (raw == null) {
      emptyStreak++;
      continue;
    }
    const normalized = normalizeCampaign(raw, Number(i));
    if (isLikelyEmptyCampaign(normalized)) {
      emptyStreak++;
      continue;
    }
    items.push(normalized);
    emptyStreak = 0;
  }

  if (items.length) return items;

  throw new Error(
    'Unable to discover campaigns: no working list/count method, and event/probe discovery failed. Double-check the contract address and ABI match the deployed contract.',
  );
}

export async function findCampaignIdByTitle(courseFund, expectedTitle) {
  const title = String(expectedTitle ?? '').trim();
  if (!courseFund || !title) return null;

  try {
    const campaigns = await fetchCampaigns(courseFund);
    const match = campaigns
      .filter((c) => String(c?.title ?? '').trim() === title)
      .sort((a, b) => (asBigInt(a?.id) > asBigInt(b?.id) ? -1 : 1))[0];
    return match?.id ?? null;
  } catch {
    return null;
  }
}

export async function fetchCampaignById(courseFund, campaignId) {
  if (!courseFund || campaignId == null) return null;

  const id = typeof campaignId === 'bigint' ? campaignId : BigInt(campaignId);
  const itemFns = ['campaigns', 'getCampaign', 'campaignById'];

  for (const name of itemFns) {
    const fn = courseFund?.[name];
    if (typeof fn !== 'function') continue;
    try {
      const raw = await fn(id);
      const normalized = normalizeCampaign(raw, Number(id));
      if (isLikelyEmptyCampaign(normalized)) return null;
      return normalized;
    } catch {
      // keep trying
    }
  }

  return null;
}

export async function createCampaign(courseFund, { title, goalWei, durationDays }) {
  const days = Number(durationDays);
  const durationSeconds = BigInt(Math.max(1, Math.round(days * 24 * 60 * 60)));
  const nowSeconds = BigInt(Math.floor(Date.now() / 1000));
  const deadlineTimestamp = nowSeconds + durationSeconds;

  return sendFirst(courseFund, [
    // Your ABI uses _durationDays, so we prefer days first
    { name: 'createCampaign', args: [title, goalWei, BigInt(Math.max(1, Math.round(days)))] },
    // fallback variants for other deployments
    { name: 'createCampaign', args: [title, goalWei, durationSeconds] },
    { name: 'createCampaign', args: [title, goalWei, deadlineTimestamp] },
    { name: 'create', args: [title, goalWei, durationSeconds] },
    { name: 'newCampaign', args: [title, goalWei, durationSeconds] },
  ]);
}

export async function donate(courseFund, { campaignId, amountWei }) {
  const id = typeof campaignId === 'bigint' ? campaignId : BigInt(campaignId);

  return sendFirst(courseFund, [
    { name: 'donateToCampaign', args: [id, { value: amountWei }] },
    { name: 'donate', args: [id, { value: amountWei }] },
    { name: 'contribute', args: [id, { value: amountWei }] },
    { name: 'fund', args: [id, { value: amountWei }] },
    { name: 'pledge', args: [id, { value: amountWei }] },
  ]);
}

export async function getUserContribution(courseFund, { campaignId, userAddress }) {
  if (!courseFund || !userAddress) return null;

  const id = typeof campaignId === 'bigint' ? campaignId : BigInt(campaignId);
  const pairs = [
    ['getUserContribution', [id, userAddress]],
    ['getContribution', [id, userAddress]],
    ['contributions', [id, userAddress]],
    ['donations', [id, userAddress]],
    ['userDonations', [id, userAddress]],
    // try swapped ordering
    ['contributions', [userAddress, id]],
    ['donations', [userAddress, id]],
  ];

  for (const [name, args] of pairs) {
    const fn = courseFund[name];
    if (typeof fn !== 'function') continue;
    try {
      const value = await fn(...args);
      return asBigInt(value, 0n);
    } catch {
      // keep trying
    }
  }

  return null;
}

export async function getErc20Metadata(token) {
  if (!token) return { symbol: 'CRT', decimals: 18 };

  let symbol = 'CRT';
  let decimals = 18;

  try {
    if (typeof token.symbol === 'function') symbol = await token.symbol();
  } catch {
    // ignore
  }

  try {
    if (typeof token.decimals === 'function') decimals = Number(await token.decimals());
  } catch {
    // ignore
  }

  return { symbol, decimals };
}
