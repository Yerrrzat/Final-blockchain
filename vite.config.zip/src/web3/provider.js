import { ethers } from 'ethers';

export const SEPOLIA_CHAIN_ID = 11155111n;
export const SEPOLIA_CHAIN_ID_HEX = '0xaa36a7';
export const SEPOLIA_CHAIN_NAME = 'Sepolia';
export const SEPOLIA_NATIVE = { name: 'SepoliaETH', symbol: 'SEP', decimals: 18 };
export const SEPOLIA_BLOCK_EXPLORER = 'https://sepolia.etherscan.io';

export function hasInjectedProvider() {
  return typeof window !== 'undefined' && typeof window.ethereum !== 'undefined';
}

export function getInjectedProvider() {
  if (!hasInjectedProvider()) {
    throw new Error('MetaMask (window.ethereum) not detected');
  }
  return window.ethereum;
}

export async function getBrowserProvider() {
  return new ethers.BrowserProvider(getInjectedProvider());
}

export function getSepoliaRpcUrl() {
  const url = import.meta.env.VITE_SEPOLIA_RPC_URL;
  return url ? String(url).trim() : '';
}

// Read-only provider for public data loading (no wallet connect required).
// Prefer an explicit RPC URL if provided; otherwise fall back to ethers default provider.
export async function getReadOnlySepoliaProvider() {
  const rpcUrl = getSepoliaRpcUrl();
  if (rpcUrl) {
    return new ethers.JsonRpcProvider(rpcUrl, 'sepolia');
  }
  return ethers.getDefaultProvider('sepolia');
}

export async function connectWallet() {
  const provider = await getBrowserProvider();

  // Triggers MetaMask connection prompt
  await provider.send('eth_requestAccounts', []);

  const network = await ensureSepolia(provider);
  const signer = await provider.getSigner();
  const address = await signer.getAddress();

  return {
    provider,
    signer,
    address,
    chainId: network.chainId,
    networkName: network.name,
  };
}

export async function getEthBalance(provider, address) {
  return provider.getBalance(address);
}

export function formatEth(wei, decimals = 4) {
  const eth = ethers.formatEther(wei ?? 0n);
  const [whole, frac = ''] = eth.split('.');
  const trimmed = frac.slice(0, decimals);
  return trimmed.length ? `${whole}.${trimmed}` : whole;
}

export function shortAddress(address) {
  if (!address) return '';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function isSepolia(chainId) {
  try {
    return BigInt(chainId) === SEPOLIA_CHAIN_ID;
  } catch {
    return false;
  }
}

export function getSepoliaTxUrl(txHash) {
  return `https://sepolia.etherscan.io/tx/${txHash}`;
}

export function getSepoliaAddressUrl(address) {
  return `https://sepolia.etherscan.io/address/${address}`;
}

export async function ensureSepolia(provider) {
  const network = await provider.getNetwork();
  if (isSepolia(network.chainId)) return network;

  const injected = getInjectedProvider();
  try {
    await injected.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: SEPOLIA_CHAIN_ID_HEX }],
    });
  } catch (err) {
    // 4902: chain not added to wallet
    if (err?.code === 4902) {
      await injected.request({
        method: 'wallet_addEthereumChain',
        params: [
          {
            chainId: SEPOLIA_CHAIN_ID_HEX,
            chainName: SEPOLIA_CHAIN_NAME,
            nativeCurrency: SEPOLIA_NATIVE,
            rpcUrls: [getSepoliaRpcUrl() || 'https://rpc.sepolia.org'],
            blockExplorerUrls: [SEPOLIA_BLOCK_EXPLORER],
          },
        ],
      });
    } else {
      throw err;
    }
  }

  return provider.getNetwork();
}
